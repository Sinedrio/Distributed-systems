// script.js

function calcularAreaRetangulo(altura, largura) {
    return altura * largura;
}

console.log("A área de um retângulo de altura 5 e largura 10 é: " + calcularAreaRetangulo(5, 10));
