package com.example.lab2sd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab2SdApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab2SdApplication.class, args);
    }

}
