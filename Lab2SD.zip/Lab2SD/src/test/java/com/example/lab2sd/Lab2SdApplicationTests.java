package com.example.lab2sd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2SdApplicationTests {

    @Test
    void contextLoads() {
    }

}
